# -*- coding: utf-8 -*-
from delete_last_comma.core import *
