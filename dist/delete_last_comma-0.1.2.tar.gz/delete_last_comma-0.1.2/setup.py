# -*- coding: utf-8 -*-

# Learn more: https://github.com/kennethreitz/setup.py

from setuptools import setup, find_packages

with open('README.rst') as f:
    readme = f.read()

with open('LICENSE') as f:
    license = f.read()

setup(
    name='delete_last_comma',
    version='0.1.2',
    description='json形式文字列中のいわゆるケツカンマを削除する',
    long_description=readme,
    author='Atsushi Suzuki',
    author_email='atushi_anaaki@yahoo.co.jp',
    url='https://github.com/anaakikutushita/delete_last_comma',
    license=license,
    packages=find_packages(exclude=('tests', 'docs'))
)
